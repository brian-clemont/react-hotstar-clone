import { combineReducers } from 'redux';
import moviesReducer from './moviesSlice';
import { configureStore } from '@reduxjs/toolkit';

const rootReducer = combineReducers({
  movies: moviesReducer,
});

const store = configureStore({
  reducer: rootReducer,
});

export default store;