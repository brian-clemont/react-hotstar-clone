import './imageSlider.css'
import { useState } from 'react';

const ImageSlider = ({ movieData, category }) => {

    const clickAction = (m) => {
        console.log("Turbo ~ clickAction ~ m:", m);
    }

    const [hoveredMovie, setHoveredMovie] = useState(null);

    const MovieDetails = ({ movie }) => {
        return (
            <div className={`movie-details-container ${hoveredMovie ? 'hovered' : ''}`}>
                <img
                    src={`https://image.tmdb.org/t/p/w500${movie.poster_path}`}
                    alt={movie.title}
                />
                <div className='movie-details'>
                    <div className='movie-details-body'>
                        <h2>{movie.title}</h2>
                        <h3>{movie?.release_date ? new Date(movie.release_date).getFullYear() : null}&nbsp;.&nbsp;{(movie.original_language).toUpperCase()}&nbsp;.&nbsp;<span className='pga-rating'>{movie.adult ? "A" : "U"} </span></h3>
                        <p className='overview'>{movie.overview}</p>
                    </div>
                </div>
            </div>
        )
    }


    return (
        <>
            <h2 className='category'>{category}</h2>
            <div className='card-container'>
                {movieData && (
                    movieData.map((movie) => (
                        <div onClick={() => { clickAction(movie) }} key={movie.id}

                            className={"card"}
                            onMouseEnter={() => setHoveredMovie(movie)}
                            onMouseLeave={() => setHoveredMovie(null)}
                        >
                            <img
                                src={`https://image.tmdb.org/t/p/w500${movie.poster_path}`}
                                alt={movie.title}
                            />
                            {hoveredMovie &&
                                hoveredMovie.id === movie.id &&
                                (
                                    <MovieDetails movie={hoveredMovie} />
                                )
                            }

                        </div>
                    ))

                )}

            </div >
        </>

    )
}

export default ImageSlider