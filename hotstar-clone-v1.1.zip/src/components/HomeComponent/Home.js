import React, { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { getPopularMovies,getTopRatedMovies,getNowPlayingMovies,getUpcomingMovies } from '../../http/apiService';
import Carousel from './CarouselComponent/Carousel';
import ImageSlider from '../ImageSlider/ImageSlider'
import {MOVIES_LOADING, MOVIES_LOADING_FAILURE } from '../../constants'


const Home = ({isLoggedIn}) => {
    const dispatch = useDispatch();
    const movies = useSelector((state) => state.movies.movie);
    const topRatedMovies = useSelector((state) => state.movies.topRated);
    const upcomingMovies = useSelector((state) => state.movies.upcoming);
    const nowPlayingMovies = useSelector((state) => state.movies.nowPlaying);
    const status = useSelector((state) => state.movies.status);
    const error = useSelector((state) => state.movies.error);

    useEffect(() => {
        dispatch(getPopularMovies());
        dispatch(getTopRatedMovies());
        dispatch(getNowPlayingMovies());
        dispatch(getUpcomingMovies());
    }, [dispatch]);


    if (status === MOVIES_LOADING) {
        return <div>Loading...</div>;
    }

    if (status === MOVIES_LOADING_FAILURE) {
        return <div>Error: {error}</div>;
    }


    return (
        <div>
            <Carousel movieData={movies} />
            <ImageSlider movieData={nowPlayingMovies} category={"Now Playing"} />
            <ImageSlider movieData={topRatedMovies} category={"Top Rated"} />
            {/* {isLoggedIn? */}
            <ImageSlider movieData={upcomingMovies} category={"Upcoming"} />
            {/* :null} */}
        </div>
    );
}


export default Home;