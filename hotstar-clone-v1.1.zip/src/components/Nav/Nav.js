import './nav.css';

const Nav = () => {

    return (
        <div className="navbar">

            <button>Logout/Login</button>
   
        </div>
    );
};


export default Nav;